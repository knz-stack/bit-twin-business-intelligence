# Bit-Twin Firearms & Tactical Supply
## Business Intelligence & Data Mining System

A responsive, single-page business intelligence interface built with HTML, CSS, vanilla JavaScript and Chart.js. It extends the existing working Supabase demo rather than replacing its database.

## Included files

- `index.html` — complete dashboard, including Executive Overview, Sales Analytics, Products & Stores, Data Mining Lab, Sales Explorer, Query Scenarios, Investor Brief and Data Warehouse pages.
- `optional_migration.sql` — optional SQL to create a restricted reporting view with a few additional analytical columns. It is not executed automatically and is not required for the core dashboard.
- `INVESTOR_PITCH.md` — presentation narrative and guardrails for describing the project without treating synthetic demo data as audited business performance.

## Run locally

1. Keep `index.html` as the entry file.
2. Open it in a modern browser, or serve the directory locally with `python -m http.server 8000` and open `http://localhost:8000`.
3. An internet connection is required for the Chart.js CDN and Supabase Data API.
4. Use the **Refresh** control to reload data from the existing reporting views.

## Supabase connection

The application retains the existing project URL and publishable key from the working demo. It reads these two public reporting views only:

- `public.vw_sales_demo` — transaction-detail rows.
- `public.vw_sales_summary` — pre-aggregated year/month/category groups.

The app pages through the detail view in batches of up to 1,000 rows, with a 50,000-row browser safety cap. The current academic dataset has 1,000 detail rows and 96 summary groups. Detail rows and summary groups have different grains and are never counted as if they were the same dataset.

The browser must not query `fact_sales` or dimension tables directly. Do not place a Supabase secret or `service_role` key in this application. The publishable key is not a substitute for appropriate PostgreSQL grants and RLS.

## Optional extended view

If the current `vw_sales_demo` does not expose `employee_id` or `sku`, some professor-assigned scenario buttons will explain that the required field is unavailable. If you choose to enable the optional extended view:

1. Review `optional_migration.sql` and run it manually in the Supabase SQL Editor.
2. Confirm that the view is exposed through the Data API and `anon` has only `SELECT` on the view.
3. In `index.html`, change `const DETAIL_VIEW = "vw_sales_demo";` to `const DETAIL_VIEW = "vw_sales_detail_ext";`.
4. Retest the connection, row counts, query scenarios and public-view permissions.

The migration creates a new view only; it does not modify or repopulate the existing tables. Do not run it if you do not need the additional fields.

## Functionality

- Live KPI cards and global date/category/store/product filters.
- Monthly sales trends, category mix, stacked time-series comparison and quantity-vs-total scatter plot.
- Product and store rankings.
- Pareto contribution analysis, IQR-based potential outlier screening and an explicitly exploratory three-month baseline.
- Sortable sales explorer, pagination and CSV export.
- Four academic query scenarios with clear limitations when required fields are not exposed.
- Investor brief with dynamic demo metrics, a staged capability roadmap and a prominent synthetic-data disclaimer.
- Data warehouse page describing the star schema and reconciling detail and summary measures when the source columns match known measure names.

## Data mining limitations

The visible charts are primarily descriptive analytics/OLAP, not machine learning. Pareto analysis and IQR screening are implemented statistical/rule-based techniques. The forecast is an unvalidated baseline, not an investment forecast. Customer segmentation needs suitable customer-level features; market-basket analysis requires a true order/receipt identifier shared by multiple product lines; churn prediction requires historical customer features and a valid target label. The app must not fabricate results for these unavailable tasks.

## Investor presentation integrity

The records currently connected to this project are synthetic academic demonstration data. The Investor Brief uses dynamically computed demo figures to illustrate how leadership could use the system. Do not present the values as actual Bit-Twin audited revenue, profitability, market share, valuation or investment returns. Verified operational data, cost/margin fields, data-quality checks and a controlled pilot would be needed for substantiated commercial claims.

## Validation status

The updated JavaScript was checked for syntax and the app was reviewed for consistent view usage and data-grain handling. A live Supabase browser test was not executed as part of this file packaging; after replacing the HTML, verify the connection status, counts, charts, filters and scenario outputs in your browser.
