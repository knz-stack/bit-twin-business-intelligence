-- BIT-TWIN OPTIONAL REPORTING-VIEW MIGRATION
-- Review before running. This script is not required for the core dashboard.
-- It does not modify, drop, truncate, or repopulate existing tables/views.
-- It creates one minimal public reporting view with safe analytical identifiers.
-- No raw table privileges are granted to anon.

-- 1) Extended sales-detail view for scenarios that require SKU, employee_id,
--    or promotion metadata not exposed by the current vw_sales_demo.
-- The view deliberately omits customer names/addresses, employee names,
-- store addresses, manager names and store licence numbers.
CREATE OR REPLACE VIEW public.vw_sales_detail_ext
WITH (security_invoker = false)
AS
SELECT
    f.sale_key,
    d.full_date,
    p.sku,
    p.product_name,
    p.category,
    p.sub_category,
    s.store_id,
    s.store_name,
    e.employee_id,
    pr.promotion_name,
    pr.promotion_type,
    f.quantity_sold,
    f.unit_price,
    f.discount_amount,
    f.background_check_fee,
    f.total_amount
FROM public.fact_sales AS f
JOIN public.dim_date AS d
    ON d.date_key = f.date_key
JOIN public.dim_product AS p
    ON p.product_key = f.product_key
JOIN public.dim_store AS s
    ON s.store_key = f.store_key
JOIN public.dim_employee AS e
    ON e.employee_key = f.employee_key
LEFT JOIN public.dim_promotion AS pr
    ON pr.promotion_key = f.promotion_key;

GRANT USAGE ON SCHEMA public TO anon;
GRANT SELECT ON public.vw_sales_detail_ext TO anon;

-- IMPORTANT:
-- If you run this view and want the dashboard to use it, change in index.html:
--   const DETAIL_VIEW = "vw_sales_demo";
-- to:
--   const DETAIL_VIEW = "vw_sales_detail_ext";
-- Then test the public Data API and verify that raw tables remain inaccessible.
-- Make sure the public schema is exposed in Supabase Data API settings.

-- 2) Future research only: this view can produce pseudonymous per-customer RFM
-- features for a trusted analytics workflow. It does not expose customer names
-- or addresses, and it deliberately grants no access to anon here. Review privacy,
-- access model and the need for this view before creating it.
--
-- CREATE OR REPLACE VIEW public.vw_customer_features
-- WITH (security_invoker = false)
-- AS
-- SELECT
--     f.customer_key,
--     COUNT(*) AS frequency,
--     SUM(f.total_amount) AS monetary,
--     MAX(d.full_date) AS last_purchase
-- FROM public.fact_sales AS f
-- JOIN public.dim_date AS d ON d.date_key = f.date_key
-- GROUP BY f.customer_key;
--
-- Do not grant this view to anon merely to make clustering work in the browser.
-- For real customer segmentation, use an appropriately restricted backend or
-- perform the analysis in a controlled environment with a privacy review.

-- Current-schema limitations:
-- * No confirmed shared order/receipt ID is available for market-basket analysis.
-- * No validated churn outcome label is present for churn prediction.
-- * The default reporting view may not expose employee_id, SKU or promotion fields;
--   the extended view above adds only the non-personal fields needed for those views.
